Liebe Nutzerin, lieber Nutzer dieser Vorlage,

diese Vorlage soll dir helfen deine Abschlussarbeit (Bachelor, Master,
Diplom,...) zu schreiben. Sie ist von der Typografie her an Deutschland
angepasst, die Titelseite ist speziell für das Corporate Design der Universität
Ulm entstanden.


Benutzung

Im oberen Teil der diplom.tex Datei sind von dir diverse Daten einzusetzen,
Name und Matrikelnummer, Titel der Arbeit, alles was später benötigt wird. In
Zeile 99 findet sich ein Todo, hier ist noch das Institut einzusetzen.
Kommentiere die richtige Fakultät ein.

In Zeile 141 zeigt ein Kommentar, das ab hier die eigentlichen Kapitel der
Arbeit eingebunden werden sollen. Ein Beispielkapitel ist in der Vorlage
enthalten (einleitung.tex).

Kurz vor dem Ende der Datei hat es noch auskommentierte Zeilen für die
verschiedenen Bibliografiestile. Diese sind nach DIN, verwende einfach den, der
in deinem Institut eingesetzt wird oder dir am besten gefällt.


Das TeXen

Meist wirst du einen Editor verwenden, der dir einiges an Unterstüzung bietet.
Die Vorlage ist für pdflatex optimiert, dein Editor sollte direkt ein PDF
erzeugen.


Dateiformate

Die Vorlage ist als UTF8 gespeichert, es hat noch eine Version in iso8859-1 und
mac. Die meisten Editoren können mittlerweile UTF8, falls es partout nicht geht
kannst du einfach die Datei diplom.tex löschen und eine der anderen beiden
umbennen. Dann solltest du noch in Zeile 26 bis 28 anpassen, in welchem Format
die Datei ist. Folgende Programme lassen sich direkt mit UTF8 nutzen:

Linux: kile, Texmaker, gedit (mit plugins) Mac: TeX-Shop Windows: Texmaker

je nach Programm muss noch eingestellt werden, dass die Dateien in UTF8 sind
(Texmaker, Tex-Shop).

UTF8 wurde gewählt, weil dieses Format Umlaute und Sonderzeichen direkt
unterstützt. Auch deutsche Anführungszeichen lassen sich ohne Sonderbefehle
nutzen.


Ulm 24.3.2009  Guido de Melo
